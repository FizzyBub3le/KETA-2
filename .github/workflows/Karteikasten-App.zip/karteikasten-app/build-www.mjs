// Baut den Ordner "www" für die Android-App: alle Dateien liegen danach IN der App,
// Formeln, Schriften und Excel-Import funktionieren ohne Internet.
import fs from "fs";
import path from "path";

const out = "www";
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, "vendor", "fonts"), { recursive: true });

for (const f of ["index.html", "manifest.webmanifest", "privacy.html"]) fs.copyFileSync(f, path.join(out, f));
fs.cpSync("icons", path.join(out, "icons"), { recursive: true });

// Formel-Darstellung und Excel-Import
fs.cpSync("node_modules/mathjax/es5", path.join(out, "vendor", "mathjax"), { recursive: true });
fs.copyFileSync("node_modules/xlsx/dist/xlsx.full.min.js", path.join(out, "vendor", "xlsx.full.min.js"));

// Schriften
const faces = [
  ["Bricolage Grotesque", "@fontsource/bricolage-grotesque", "bricolage-grotesque-latin", [500, 700]],
  ["Atkinson Hyperlegible", "@fontsource/atkinson-hyperlegible", "atkinson-hyperlegible-latin", [400, 700]],
  ["JetBrains Mono", "@fontsource/jetbrains-mono", "jetbrains-mono-latin", [500]],
];
let css = "";
for (const [family, pkg, base, weights] of faces) {
  for (const w of weights) {
    const file = `${base}-${w}-normal.woff2`;
    const from = path.join("node_modules", pkg, "files", file);
    if (!fs.existsSync(from)) { console.warn("Schrift fehlt, nutze Ersatzschrift:", file); continue; }
    fs.copyFileSync(from, path.join(out, "vendor", "fonts", file));
    css += `@font-face{font-family:"${family}";font-style:normal;font-weight:${w};font-display:swap;src:url(fonts/${file}) format("woff2")}\n`;
  }
}
fs.writeFileSync(path.join(out, "vendor", "fonts.css"), css);

// Verweise im HTML auf die lokalen Dateien umstellen
let html = fs.readFileSync("index.html", "utf8");
const swap = (from, to) => {
  if (!html.includes(from)) throw new Error("Nicht gefunden in index.html: " + from);
  html = html.replace(from, to);
};
html = html.replace(/<link rel="preconnect"[^>]*>\n?/, "");
html = html.replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>/, '<link rel="stylesheet" href="vendor/fonts.css">');
swap("https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js", "vendor/mathjax/tex-svg.js");
swap("https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js", "vendor/xlsx.full.min.js");
// In der App gibt es keinen Service Worker
html = html.replace(/if\("serviceWorker" in navigator\)[^\n]*\n/, "");
fs.writeFileSync(path.join(out, "index.html"), html);
console.log("www/ ist fertig.");

// Service Worker: macht die App offline nutzbar.
// Bei jeder neuen Version VERSION hochzählen, damit Handys das Update laden.
const VERSION = "karteikasten-v1.6.0";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./privacy.html",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/maskable-192.png",
  "./icons/maskable-512.png"
];
// Fremde Bibliotheken (Formeln, Schriften, Excel-Import): beim ersten Laden zwischenspeichern
const CDN_HOSTS = ["cdn.jsdelivr.net", "cdnjs.cloudflare.com", "fonts.googleapis.com", "fonts.gstatic.com"];
const PRECACHE_CDN = [
  "https://cdn.jsdelivr.net/npm/mathjax@3.2.2/es5/tex-svg.js",
  "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    await cache.addAll(APP_SHELL);
    // CDN-Dateien einzeln, damit ein Fehler die Installation nicht abbricht
    await Promise.all(PRECACHE_CDN.map((u) => cache.add(new Request(u, { mode: "cors" })).catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // App-Seite: zuerst Netz (für Updates), sonst Zwischenspeicher
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(VERSION).then((c) => c.put("./index.html", copy));
        return res;
      }).catch(() => caches.match("./index.html"))
    );
    return;
  }

  // Eigene Dateien und Bibliotheken: zuerst Zwischenspeicher, im Hintergrund aktualisieren
  if (url.origin === location.origin || CDN_HOSTS.includes(url.hostname)) {
    event.respondWith((async () => {
      const cache = await caches.open(VERSION);
      const hit = await cache.match(req);
      const net = fetch(req).then((res) => {
        if (res && (res.ok || res.type === "opaque")) cache.put(req, res.clone());
        return res;
      }).catch(() => null);
      return hit || (await net) || new Response("", { status: 504 });
    })());
  }
});
